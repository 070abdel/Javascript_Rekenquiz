<?php
$leeftijd = "15";



if ($leeftijd > 16) {
    echo "Je mag praktijkexamen voor je scooterrijbewijs doen. <br>";
}
else if ($leeftijd < 16) {
    echo "Je mag geen praktijkexamen voor je scooterrijbewijs doen. <br>";
}
if ($leeftijd >= 18) {
    echo "Je mag stemmen, want je hebt een stempas";
}
else
    echo "Je mag niet stemmen, want je hebt geen stempas";
?>