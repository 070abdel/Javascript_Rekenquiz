<?php
    $tijd = date("H");
    $ochtend = $tijd < "12";
    $middag = $tijd >= "12" && $tijd < "18";
    $avond = $tijd >= "18" && $tijd <= "24";

    switch($tijd) {
       case $ochtend : echo "Het is ochtend."; break;
       case $middag : echo "Het is middag."; break;
       case $avond : echo "Het is avond."; break;

       default : echo "Het is nacht."; break;
    }
?>