<?php
$prijs= 60;
$prijsa = 1.19;
$prijsb = 1.11;
$prijsc = 1.16;
$prijs1 = $prijs * $prijsa;
$prijs2 = $prijs * $prijsb;
$prijs3 = $prijs * $prijsc;


if ($prijs > 150) {
    echo "Oude prijs: $prijs. Na verhoging van 19% is de prijs €$prijs1";
}
else if ($prijs < 55) {
    echo "Oude prijs: $prijs. Na verhoging van 11% is de prijs €$prijs2";
}
else
    echo "Oude prijs: $prijs. Na verhoging van 16% is de prijs €$prijs3";

?>
