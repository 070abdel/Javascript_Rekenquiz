<?php
$tijd = date("G");

if ($tijd <= 17.00) {
echo "De airco moet aanstaan.";
} else
    echo "De airco moet uitstaan.";
?>

