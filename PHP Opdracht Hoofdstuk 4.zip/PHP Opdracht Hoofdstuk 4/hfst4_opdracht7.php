<?php
$iphoneprijs = "1000";
$telefoonhoesje = "50";
$spaargeld = "1050";
$geldtekort = $iphoneprijs - $spaargeld;

if ($geldtekort > 250 && $geldtekort > 0) {
    echo "Je hebt $spaargeld euro gespaard. Je komt nog $geldtekort euro tekort. Je kunt beter een baantje zoeken!";
}
else if ($geldtekort < 1000 && $geldtekort > 0) {
    echo "Je hebt $spaargeld euro gespaard, maar je komt nog $geldtekort euro tekort. Het lukt je bijna om een iPhone kopen!";
}
else if ($spaargeld >= 1000 && $spaargeld < 1050) {
    echo "Je hebt $spaargeld euro gespaard. Dat is genoeg geld om een iPhone te kopen!";
}
else if ($spaargeld >= 1050) {
    echo "Je hebt $spaargeld euro gespaard. Dat is genoeg geld om een iPhone te kopen met en een hoesje erbij!";
}

?>