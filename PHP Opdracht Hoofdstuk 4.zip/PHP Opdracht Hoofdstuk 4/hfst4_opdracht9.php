<?php
function checkValidity($zijde1, $zijde2, $zijde3)
{
    if ($zijde1 + $zijde2 <= $zijde3 ||
        $zijde1 + $zijde3 <= $zijde2 ||
        $zijde2 + $zijde3 <= $zijde1)
        return false;
    else
        return true;
}

$zijde1 = 1;
$zijde2 = 2;
$zijde3 = 1;

{
 if (checkValidity($zijde1, $zijde2, $zijde3)) {
     echo "Zijde 1: $zijde1 <br>";
     echo "Zijde 2: $zijde2 <br>";
     echo "Zijde 3: $zijde3 <br>";
     echo "Kan wel!";
 }
 else {
     echo "Zijde 1: $zijde1 <br>";
     echo "Zijde 2: $zijde2 <br>";
     echo "Zijde 3: $zijde3 <br>";
     echo "Kan niet!";
 }
}
?>