<?php
if (isset($_POST['submit'])) {
    $eerstegetal = $_POST['eerstegetal'];
    echo "Eerste getal:".$eerstegetal. "<br/>";
    $tweedegetal = $_POST['tweedegetal'];
    echo "Tweede getal:".$tweedegetal. "<br/>";
}
?>