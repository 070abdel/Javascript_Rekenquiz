<?php
$number = 39;
function check($getal) {
    if ($getal == 0)
        return 1;
    else if($getal == 1)
        return 0;
    else if($getal<0)
        return check(-$getal);
    else
        return check($getal-2);
}
if(check($number))
    echo "Is het getal $number even? Ja.";
else
    echo "Is het getal $number even? Nee.";
?>